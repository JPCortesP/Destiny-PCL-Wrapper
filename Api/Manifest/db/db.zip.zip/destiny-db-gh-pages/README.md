# destiny-db
Revision history for http://bungienetplatform.wikia.com/wiki/Manifest
